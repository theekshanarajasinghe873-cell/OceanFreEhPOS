package com.oceanfresh.pos;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.content.Context;

public class MainActivity extends Activity {
    private WebView web;
    @SuppressLint("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new PrintBridge(), "AndroidPrint");
        web.loadUrl("file:///android_asset/index.html");
    }
    public class PrintBridge {
        @android.webkit.JavascriptInterface public void print() {
            runOnUiThread(() -> {
                try {
                    PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);
                    pm.print("Ocean Fresh Bill", web.createPrintDocumentAdapter("Ocean Fresh Bill"), new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.UNKNOWN_PORTRAIT).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
                } catch(Exception e) { Toast.makeText(MainActivity.this,"Printing is not available on this device",Toast.LENGTH_SHORT).show(); }
            });
        }
    }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
